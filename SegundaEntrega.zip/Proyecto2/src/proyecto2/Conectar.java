
package proyecto2;
import java.sql.*;
import javax.swing.JOptionPane;
//Se Importo el driver de conexion a MSQL en Libraries
public class Conectar {

    public Connection conectar(){
        
          Connection con=null;
    
     try{
            
            
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
           String URL = 
			"jdbc:mysql://localhost/basetareas?serverTimezone=UTC";
	String USER = "root";
	 String PASSWORD = "";
                    
             con=DriverManager.getConnection(URL,
				USER, PASSWORD);
            System.out.println("Conexion Establecida");
            JOptionPane.showMessageDialog(null,"Conexion Establecida");
        
        }
        catch(SQLException e){
            e.getMessage();
            System.out.println("Error de MSQL   " + e);
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(Exception e){
            System.out.println("Error  "+ e.getMessage());   
        }
    
    
    return con;
    }
    
}
